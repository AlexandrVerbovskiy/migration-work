/*function to randomize arrays */
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        const temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}

//get parsed study code from url
function studyCode() {
    const href = window.location.href;
    const parts = href.split("/");
    const lastPart = parts[parts.length - 1];
    const code = lastPart === "study" ? null : lastPart;
    return code;
}

//get saved key value to actual study code
function getStorageByKey(key) {
    const code = studyCode();
    const codeObj = JSON.parse(localStorage.getItem(code))
    if (!codeObj) return null;
    return codeObj[key];
}

//save key value to actual study code
function setStorageByKey(key, value) {
    const code = studyCode();
    const codeObj = JSON.parse(localStorage.getItem(code)) || {};
    codeObj[key] = value;
    localStorage.setItem(code, JSON.stringify(codeObj))
}

function buildScript(id, src = null) {
    const s = document.createElement('script');
    s.id = id;

    if (src) {
        s.src = src;
    } else {
        s.src = chrome.runtime.getURL('js/' + id + '.js');
    }

    (document.head || document.documentElement).appendChild(s);
}

function startListeningDraw(elementToObserve, checker, singleCall = false) {
    let observer = new MutationObserver(mutationRecords => {
        mutationRecords.forEach(record => {
            if (record.nextSibling) {
                checker(record)
                if (singleCall) {
                    observer.disconnect();
                }
            }
        })
    });

    observer.observe(elementToObserve, {
        childList: true,
        subtree: true,
        characterDataOldValue: true
    });
    return observer;
}


function showLoader() {
    const block = `<div class="loader-parent">
        <div class="loader"></div>
        <div class="loader-text"></div>
    </div>`

    $("body").append(block);
}

function removeLoader() {
    $(".loader-parent").remove();
}

function hasLoader() {
    return $(".loader-parent").length > 0
}

function setLoaderText(text) {
    $(".loader-text").text(text);
}