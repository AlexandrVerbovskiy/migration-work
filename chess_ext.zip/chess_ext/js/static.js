const logo = "logo.png";
const paypal = "https://docs.google.com/document/d/15xadE-ph7CyNDWt7tgIT_Pk4Fle_ryT5DO2yzunfyAc/";
const siteUrl = "https://lichess.org/study/";
const requestFormat = ".pgn";

const logoUrl = chrome.runtime.getURL(logo);
const cooldownTime = 15000;
const extensionName = "DRILL CHESS";
const timeReopenSettings = 400;
const mainScriptTime = 200;
const timeCloseGoodMove = 270;