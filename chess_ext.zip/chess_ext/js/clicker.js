let cachedElems = {};

function arraysEqual(a, b) {
    if (a === b) return true;
    if (a == null || b == null) return false;
    if (a.length !== b.length) return false;

    for (let i = 0; i < a.length; i++) {
        if (a[i] !== b[i]) return false;
    }
    return true;
}

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        const temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}

//get parsed study code from url
function studyCode() {
    const href = window.location.href;
    const parts = href.split("/");
    const lastPart = parts[parts.length - 1];
    const code = lastPart === "study" ? null : lastPart;
    return code;
}

//get saved key value to actual study code
function getStorageByKey(key) {
    const code = studyCode();
    const codeObj = JSON.parse(localStorage.getItem(code))
    if (!codeObj) return null;
    return codeObj[key];
}


function getFilteredMoves() {
    const fStep = getStorageByKey("firstStepIndex");
    const title = sessionStorage.getItem("actualChapter");
    const actualChild = $(".analyse__moves .tview2").children();
    const children = actualChild.length > 0 ? actualChild : (cachedElems[title] || []);
    cachedElems[title] = children;
    const elems = [];
    let actualElem = {};

    for (let i = 0; i < children.length; i++) {
        if (children[i].localName == "index") {
            if (actualElem["index"]) {
                elems.push(actualElem);
                actualElem = {};
            }
            actualElem["index"] = children[i];
        }
        if (children[i].localName === "move") {
            if (!actualElem["moves"]) {
                actualElem["moves"] = [];
            }
            actualElem["moves"].push(children[i]);
        }
    }

    if (actualElem["index"]) {
        elems.push(actualElem);
        actualElem = {};
    }

    const filtered = [];
    const index = getStorageByKey("chessColor") == "black" ? 0 : 1;

    for (let i = 0; i < elems.length; i++) {
        if (elems[i]["index"].innerText <= fStep || elems[i]["moves"].length < 2) continue;

        if (index === 1 && i === elems.length - 1) continue;

        if (!elems[i]["moves"][index].className.includes("empty")) {
            filtered.push(elems[i]["moves"][index])
        }
    }

    return filtered;
}

function clickRnd() {
    const moves = getFilteredMoves();

    if (moves.length > 0) {
        shuffleArray(moves);
        const elem = moves[0];
        $(elem).trigger("mousedown");
    }
}