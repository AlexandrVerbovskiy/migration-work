let ignoreClick = false;
setTimeout(() => ignoreClick = false, cooldownTime);

function buildPopup(chapters = [], savedChapters = [], savedFirstIndex = 0) {
    const isAllChecked = savedChapters.length === chapters.length || savedChapters.length === 0
    const allChecked = isAllChecked ? "checked" : "";

    //generating header block popup and static checkbox on chapterList
    const formStart = `<div id="chess_popup">
        <span class="close-btn">X</span>
        <form>
        <div class="main_filter">
            <div class="chapter_checkboxes">
                <div class="popup_title">
                    Select Chapters
                </div>
                <div class="chapter_list">
                    <div>
                        <input type="checkbox" class="all" ${allChecked}> All
                    </div>
        `;

    //generating dynamic checkboxes to select every chapter
    const chapterInputs = chapters.map(chapter => {
        //if chapter was selected at previous, mark it
        const checked = (savedChapters.includes(chapter) || isAllChecked) ? "checked" : "";
        return `<div><input type="checkbox" class="${chapter}" ${checked}> ${chapter}</div>`
    }).join(" ");

    //if the information about value of the first step, which is transmitted by the parameter,
    //indicates that the step is set and it is greater than zero - do not check checkbox,
    //otherwise - check and write value in the input
    const anyChecked = savedFirstIndex == 0 ? "checked" : "";
    const numberValue = "value=" + savedFirstIndex;
    const whiteColorChecked = getStorageByKey("chessColor") == "white" ? "checked" : "";
    const blackColorChecked = getStorageByKey("chessColor") !== "white" ? "checked" : "";

    //generate section with first step input
    const stepsFilter = `</div>
        </div>
        <div class="popup-body">
            <div class="extension-name"><span>${extensionName}</span></div>
                <div class="step_select">
                    <div class="popup_title">
                        Select Your Color
                    </div>
                    <div class="colors">
                        <input type="checkbox" class="white" ${whiteColorChecked}> white
                        <input type="checkbox" class="black" ${blackColorChecked}> black
                    </div>
                    <div class="step_popup_title">
                        Select Move Limits
                    </div>
                    <div>
                        <input type="checkbox" class="any" ${anyChecked}> any
                    </div>
                    <div>
                        From move <input type="number" ${numberValue} min="0"> onwards
                    </div>
                    <img class="logo" src="${logoUrl}" width="160" height="160"/>
            </div>`;


    //close form and generate button
    const formEnd = ` </div>
            <div class="error"></div>
            <div class="popup-buttons">
                <button type = "button"> Filter </button>
                <a class="donate-link" target="_blank" href="${paypal}">
                    <div class="donate-button">
                        <div>SUPPORT US &</div>
                        <div>DONATE</div>
                        <div>contact & info</div>
                    </div>
                </a>
            </div>
        </form> 
    </div>`;

    return formStart + chapterInputs + stepsFilter + formEnd;
}

function buildHeaderPopup() {
    return `<div id="chess_popup_header">${extensionName}</div>`;
}

function initHeaderPopup(parentSelector, onInit, titles = []) {
    //appending header to element
    $(parentSelector).append(buildHeaderPopup());
    //on click header remove it and build popup
    $("#chess_popup_header").click(() => {
        $("#chess_popup_header").remove();
        initPopup(parentSelector, onInit, titles);
    })
}

function initHeaderWithTimeout(parentSelector, onInit, titles = []) {
    ignoreClick = true;
    initHeaderPopup(parentSelector, onInit, titles);
}

function validatePopup(chapters, firstStep) {
    if (chapters.length === 0) {
        return "Please select at least one chapter!";
    }

    if (firstStep < 0) {
        return "Move limit must be greater than 0!";
    }

    if (ignoreClick) return "Try again in a few seconds. Sorry for the delay";

    return false;
}

function initPopup(parentSelector, onInit, titles = []) {

    const clearError = () => {
        $("#chess_popup .error").text("");
        $("#chess_popup button").removeAttr("disabled");
    }

    //remove popup and build header
    const onRemovePopup = () => {
        $("#chess_popup").remove();
        initHeaderPopup(parentSelector, onInit, titles);
    }

    //getting info about prev actions on page with filter
    const savedFirstIndex = getStorageByKey("firstStepIndex") || 0;
    const savedChapters = getStorageByKey("selectedChapters") || [];

    $(parentSelector).append(buildPopup(titles, savedChapters, savedFirstIndex));

    $("#chess_popup form").submit(function (e) {
        e.preventDefault();
    });

    $("#chess_popup .close-btn").click(function () {
        onRemovePopup();
    });

    //if user check all chapters - check all checkboxes
    $(".chapter_checkboxes .all").click(function () {
        clearError()
        const isCheck = $(this).prop("checked");
        $(`.chapter_checkboxes input[type="checkbox"]:not(.all)`).prop("checked", isCheck);
    });

    //if user uncheck chapter and checkbox "all chapters" is active - change it
    //if user check all chapter and checkbox "all chapters" isn't active - change it
    $(`.chapter_checkboxes input[type="checkbox"]:not(.all)`).click(function () {
        clearError()
        const diff = titles.length - $(`.chapter_checkboxes input[type="checkbox"]:not(.all):checked`).length;
        if (diff === 0) {
            $(".chapter_checkboxes .all").prop("checked", true);
        } else if (diff === 1) {
            $(".chapter_checkboxes .all").prop("checked", false);
        }
    });

    //show value in input depending on the checkbox
    $(".step_select .any").click(function () {
        clearError()
        if ($(this).prop("checked")) {
            $(`.step_select input[type="number"]`).val(0);
        } else {
            $(`.step_select input[type="number]"`).val(1);
        }
    });

    //check checkbox "any" depending on the input
    $(`.step_select input[type="number"]`).on("input", function () {
        clearError()
        $(".step_select .any").prop("checked", $(this).val() == 0);
    });

    $("#chess_popup .colors input").click(function () {
        clearError()
        if ($(this).hasClass("black")) {
            $("#chess_popup .colors .white").prop("checked", !$(this).prop("checked"));
        } else {
            $("#chess_popup .colors .black").prop("checked", !$(this).prop("checked"));
        }
    })

    $("#chess_popup button").click(function () {
        //cleaning error span
        clearError()

        //get info about selected chapters
        const selectedChapters = [];
        $(`.chapter_checkboxes input:checked:not(.all)`).each(function () {
            selectedChapters.push($(this).attr('class'));
        });

        //get info about first step
        const firstStepIndex = $(".step_select .any").prop("checked") ? 0 : +$(`.step_select input[type="number"`).val();

        const chessColor = $("#chess_popup .colors input:checked").attr('class');

        //validate getted info
        const resValidate = validatePopup(selectedChapters, firstStepIndex);
        if (resValidate) {
            $("#chess_popup .error").text(resValidate);
            if (resValidate != "Try again in a few seconds. Sorry for the delay") {
                $("#chess_popup button").attr("disabled", "disabled");
            }
            return;
        }

        //save info
        setStorageByKey("firstStepIndex", firstStepIndex);
        setStorageByKey("selectedChapters", selectedChapters);
        setStorageByKey("chessColor", chessColor);

        //call callback and remove popup
        onInit(selectedChapters, firstStepIndex);
        onRemovePopup();
    });
}

function initErrorPopup(parentSelector, onInit, errorMessage, titles = []) {
    $("#chess_popup_header").remove();
    initPopup(parentSelector, onInit, titles);
    $("#chess_popup .error").text(errorMessage);
    $("#chess_popup button").attr("disabled", "disabled");
}

function runPopupScript() {
    $("#chess_popup button").trigger("click");
}