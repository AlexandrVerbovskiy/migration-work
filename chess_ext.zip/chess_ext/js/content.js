const chapterArr = []; //saved chapter elements
const chapterTitleArr = []; //saved chapter titles
const cachedElements = {}; //cached elements chapter
let filteredChapterArr = []; //filtered chapter elements
let firstStepIndex = 0; //first step for filter
let getJumpBtns = null;
let includedKeys = [];
let blockedChapters = [];
let normalChapters = [];
let rebuilding = false;

function getFilteredChaptersArr() {
    filteredChapterArr = includedKeys.length > 0 ?
        chapterArr.filter(chapter => includedKeys.includes(chapter.find("h3").text())) :
        chapterArr;

    return filteredChapterArr;
}

function getChapterTitle() {
    return $(".study__chapters .active h3").text();
}

function rebuildChapters() {
    //filter the saved titles and redraw them
    $(".study__chapters").empty();

    //remove cached info about chapters
    chapterArr.forEach(elem => elem.removeClass("loading"));

    filteredChapterArr = getFilteredChaptersArr();

    filteredChapterArr.forEach((elem, index) => {
        const number = index + 1;
        elem.find("span").text(number)

        elem.click(function () {
            sessionStorage.setItem("actualChapter", elem.find("h3").text())
        })
        $(".study__chapters").append(elem);
    });

    filteredChapterArr = filteredChapterArr.filter(chapter => !blockedChapters.includes(chapter.find("h3").text()));

    //redraw steps
    if (filteredChapterArr.length > 0) {
        shuffleArray(filteredChapterArr);
        const title = filteredChapterArr[0].find("h3").text();
        filteredChapterArr[0].click();
        return title;
    }
    showError("There are no questions for the specified filters");
    return "";
}

function getFilteredMovesCount() {
    const fStep = getStorageByKey("firstStepIndex");
    const title = sessionStorage.getItem("tempClickedChapter");
    const actualChild = $(".analyse__moves .tview2").children();
    const children = cachedElements[title] || (actualChild.length > 0 ? actualChild : []);
    cachedElements[title] = children;
    const elems = [];
    let actualElem = {};

    for (let i = 0; i < children.length; i++) {
        if (children[i].localName == "index") {
            if (actualElem["index"]) {
                elems.push(actualElem);
                actualElem = {};
            }
            actualElem["index"] = children[i];
        }
        if (children[i].localName === "move") {
            if (!actualElem["moves"]) {
                actualElem["moves"] = [];
            }
            actualElem["moves"].push(children[i]);
        }
    }

    if (actualElem["index"]) {
        elems.push(actualElem);
        actualElem = {};
    }

    const filtered = [];
    for (let i = 0; i < elems.length; i++) {
        if (elems[i]["index"].innerText <= fStep || elems[i]["moves"].length < 2) continue;


        if (!elems[i]["moves"][1].className.includes("empty")) {
            filtered.push(elems[i]["moves"][1])
        }
    }

    return filtered.length;
}

function firstRndMoveClick() {
    if ($("#clicker").length < 1) {
        buildScript('clicker');
    }
    $("#callClick").remove();
    buildScript('callClick');

    /*if(blockedChapters.includes(title)){
        rebuildChapters();
    }*/

    rebuilding = false;
    return;
}

function handleRebuildChapter() {
    rebuilding = true;
    const prevChapter = getChapterTitle();
    const newChapter = rebuildChapters();
    if (prevChapter == newChapter) {
        firstRndMoveClick();
    }
}

function init() {
    //local save info about first step and keys
    firstStepIndex = getStorageByKey("firstStepIndex");
    includedKeys = getStorageByKey("selectedChapters");

    //start observing the main block to understand if the chapters have been changed on the page to change the order of the steps
    const elementToObserve = document.querySelector(".analyse.has-players");
    const checkRecord = (record) => {
        //if block with steps was rewrited - rebuild steps
        if (record.addedNodes.length > 0 && record.addedNodes[0].className && record.addedNodes[0].className.includes("analyse__tools")) {
            firstRndMoveClick();
        }
    }
    startListeningDraw(elementToObserve, checkRecord);

    changeOptions();
}

function onFilterClick() {
    setStorageByKey("loading", true);
    setStorageByKey("specialLoading", true);
    location.reload()
}

let isFirstChaptersUpdate = true;

function afterClickChapters() {
    if (isFirstChaptersUpdate) {
        setInterval(() => {
            if (rebuilding) return;

            const unactivePreviewBtn = $(".preview:not(.active)");
            if (unactivePreviewBtn.length > 0) {
                unactivePreviewBtn.trigger("click");
            }

            const activePreviewBtn = $(".preview.active:not(.marked)");
            if (activePreviewBtn.length > 0) {
                const clone = activePreviewBtn.clone();
                clone.off();
                clone.removeClass("preview");
                activePreviewBtn.after(clone);
                activePreviewBtn.css("display", "none");
                activePreviewBtn.addClass("marked");
            }

            if ($(".feedback.good").length > 0 || $(".feedback.end").length > 0) {
                let actualElem = $(".feedback.end");
                const div = "<div class='extension-good-move'><span>Good move</span></div>"

                if ($(".feedback.good").length > 0) {
                    actualElem = $(".feedback.good");
                }

                actualElem.replaceWith(div);

                const timeout = setTimeout(() => {
                    $(".extension-good-move").replaceWith(actualElem);
                    handleRebuildChapter();
                    clearTimeout(timeout);
                }, timeCloseGoodMove);
            }
        }, mainScriptTime)
        isFirstChaptersUpdate = false;
        $("body").addClass("extension-start");
    }

    setStorageByKey("loading", false);
    handleRebuildChapter();
    initHeaderWithTimeout("body", onFilterClick, chapterTitleArr);
    removeLoader();
}

function clickEverChapter() {
    const needed = chapterArr.length;
    const afterValidate = () => {
        let i = 0;
        return () => {
            const rate = Math.floor((i + needed) * 100 / (needed * 2));
            setLoaderText(rate + "%");
            i++;
            if (i == needed) {
                afterClickChapters();
            }
        }
    }

    const code = studyCode();
    const getUrl = (id) => siteUrl + code + "/" + id + requestFormat;

    const callback = afterValidate();

    chapterArr.forEach((chapter, index) => {
        const title = chapter.find("h3").text();

        const parse = () => parserPgn(getUrl(chapter.data("id")), title, callback);

        if (needed > 15) {
            setTimeout(parse, 510 * index)
        } else {
            parse();
        }
    })
}

function changeOptions() {
    const formatChapterOptions = () => {
        const color = getStorageByKey("chessColor") || "white";
        $('#chapter-orientation')
            .val(color)
            .trigger('change');

        $('#chapter-mode')
            .val('gamebook')
            .trigger('change');

        $("#modal-overlay button[type='submit']").trigger('click');
    }

    filteredChapterArr = getFilteredChaptersArr();
    const countChapters = filteredChapterArr.length;

    const handleModalChanges = (record) => {
        if (filteredChapterArr.length > 0) {
            if (record.addedNodes.length > 0) {
                record.addedNodes.forEach(elem => {
                    if (elem.id == "modal-overlay") {
                        setTimeout(() => formatChapterOptions(), 100)
                    }
                })
            }

            if (record.removedNodes.length > 0) {
                record.removedNodes.forEach(elem => {
                    if (elem.id == "modal-overlay") {
                        setTimeout(() => {
                            i++;
                            nextChapterClick();
                        }, 100)
                    }
                })
            }
        }
    }

    let i = 0;
    const nextChapterClick = () => {
        if (i < countChapters) {
            const rate = Math.floor(i * 100 / (countChapters * 2));
            setLoaderText(rate + "%");
            filteredChapterArr[i].find(".act").trigger("click");
        } else {
            observer.disconnect();
            clickEverChapter();
        }
    }

    showLoader();
    nextChapterClick();

    const elementToObserve = document.querySelector(".analyse.has-players");

    const observer = startListeningDraw(elementToObserve, handleModalChanges);
}

function showError(message) {
    initErrorPopup("body", onFilterClick, message, chapterTitleArr)
}

function myRemover(text, start, end) {
    let hasBrackets = true;
    while (hasBrackets) {
        hasBrackets = false;
        if (text.includes(start) && text.includes(end)) {
            const lastStart = text.lastIndexOf(start);
            const firstEnd = text.indexOf(end, lastStart);
            text = text.substring(0, lastStart) + text.substring(firstEnd + 1);
            hasBrackets = true;
        }
    }
    return text;
}

function isNormal(steps, title) {
    const fStep = getStorageByKey("firstStepIndex");
    const color = getStorageByKey("chessColor");

    const resFiltered = [];
    steps.forEach((row, index) => {
        const reg = new RegExp(" +");
        const splittedRow = row.trim().split(reg);

        if (splittedRow.length < 2 && index === 0 && color == "white") {
            resFiltered.push(row);
        } else if (splittedRow.length < 2 && index === steps.length - 1 && color == "black") {
            resFiltered.push(row);
        } else if (!(index === steps.length - 1 && color == "black")) {
            resFiltered.push(row);
        }

    })

    if (resFiltered.length <= fStep) {
        blockedChapters.push(title);
    } else {
        normalChapters.push(title);
    }
}

function parserPgn(url, title, callback) {
    fetch(url).then(res => res.text()).then(data => {
        let splittedDate = data.split("[Annotator")[1].split("]");
        splittedDate.shift();
        splittedDate = splittedDate.join("]");
        if (splittedDate.includes("SetUp")) {
            splittedDate = data.split("[SetUp")[1].split("]");
            splittedDate.shift();
            splittedDate = splittedDate.join("]");
        }
        const content = splittedDate;

        let tempResFilter = myRemover(content, "(", ")");
        tempResFilter = myRemover(tempResFilter, "{", "}");
        const reg2 = new RegExp(/\*/, 'g');
        const resFilter = tempResFilter.replaceAll(reg2, "");

        const splitReg = new RegExp(/\d+\. /, 'g');
        let resSplit = resFilter.trim("\n").split(splitReg);
        if (resSplit.length > 0 && resSplit[0].length < 1) {
            resSplit.shift();
        }

        const regNumberDots = new RegExp(/\d*\.\.\./, 'g');
        resSplit = resSplit.map(row => row.replaceAll(regNumberDots, ""))
        isNormal(resSplit, title);
        callback();
    }).catch(err => {
        alert("Many chapters, the site blocked the request. Try reducing the number of chapters!")
        location.reload()
    });
}


if ($(".study__chapters").length > 0) {
    //get chapters, their titles from study window and order chapter elements
    $(".study__chapters>div:not( *:contains('Add a new chapter'))").each(function () {
        chapterArr.push($(this));
        const title = $(this).find("h3").text();
        chapterTitleArr.push(title);
    })

    if (getStorageByKey("loading")) {
        init();
    } else {
        initPopup("body", onFilterClick, chapterTitleArr);
    }
}

window.onbeforeunload = function (e) {
    if (!getStorageByKey("specialLoading")) {
        setStorageByKey("loading", false);
    } else {
        setStorageByKey("specialLoading", false);
    }
};